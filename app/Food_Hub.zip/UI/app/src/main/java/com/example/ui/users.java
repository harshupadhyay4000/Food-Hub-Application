package com.example.ui;

public class users {
    String userName;

    public users(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    public users(){}
}
